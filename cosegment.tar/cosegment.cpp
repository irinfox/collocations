/************************************************************************
* Unit Name:     cosegment.cpp                                          *
* Author:        Vidas Daudaravicius                                    *
* e-mail:        vidas@donelaitis.vdu.lt                                *
* Date Created:  14-Mar-2010                                            *
* cosegment Copyright (c) 2010 Vidas Daudaravicius.                     *
*                                                                       *
* This program is free software: you can redistribute it and/or modify  *
* it under the terms of the GNU General Public License as published by  *
* the Free Software Foundation, either version 3 of the License, or     *
* (at your option) any later version.                                   *
*                                                                       *
* This program is distributed in the hope that it will be useful,       *
* but WITHOUT ANY WARRANTY; without even the implied warranty of        *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
* GNU General Public License for more details.                          *
*                                                                       *
* You should have received a copy of the GNU General Public License     *
* along with this program.  If not, see <http://www.gnu.org/licenses/>. *
************************************************************************/
//g++ -O2 -o lice lice.cpp

#include <math.h>
#include <dirent.h>
#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <map>
#include <fstream>
#include <string.h>
#include <stdlib.h>

#define OverwriteOriginalFile false
#define LimitCollocationLength false
#define CollocationLengthLimit 7
#define OutputCollocationsDictionary true

using namespace std;

struct item{
  string word;
  long int freq;	
};

bool compare_val (const item &i,const item &j){  return (i.freq > j.freq); }  // mazejimo tvarka
bool compare_key (const item &i,const item &j){  return (i.word < j.word); }  // didejimo tvarka

void findFiles(vector<string>& files, string dir);
void saveVectorToFile(string file, vector<item> &v);
map<string,int>::iterator addToMap(map<string,int> &mymap, const string &line, const int f=1);
long double dice(map<string,int> &dict1, map<string,int> &dict2, string& word1, string & word2);
void splitSegment(vector<long double> &grs, vector<long double> &grs2, int st, int ln);
void makeCollSegmentation(vector<string>& list, map<string,int> &dict1, map<string,int> &dict2, map<string,int> &coll, FILE* output_file);
void makeStats(vector<string>& list,map<string,int> &dict1,map<string,int> &dict2);
void changeMapToVector(map<string, int> &m,vector<item> &v);
void process_file_coll(string file, string file_out, map<string,int>& dict1, map<string,int> &dict2, map<string,int> &coll);
void process_file_freq(string file,map<string,int> &dict1,map<string,int> &dict2);




int main(int argc, char* argv[]){
  unsigned int i;
  string file, file_out, dirs;
  map<string,int> dict1, dict2, coll;
  vector<string> files;
  dirs = "./corpus";
  findFiles(files,dirs);
  if(files.size()>0){
// surenkame statistika
  fputs ("\nGathering statistics needed for collocation segmentation\n",stdout); fflush (stdout);
  for(i=0;i<files.size();i++){
    file = files[i];
    process_file_freq(file,dict1,dict2);
    if(div(i,10).rem==0)  { fputs ("*",stdout); fflush (stdout);  }
    if(div(i,1000).rem==0){ fputs ("\n",stdout); fflush (stdout); }
  }

// suzymime stab junginius
  fputs ("\nPerforming collocation segmentation\n",stdout);  fflush (stdout);
  for(i=0;i<files.size();i++){
    file = files[i];
    file_out = file+".c";
    process_file_coll(file, file_out, dict1, dict2, coll);
    if(OverwriteOriginalFile){
      remove(file.c_str());
      rename(file_out.c_str(),file.c_str());
    }
    if(div(i,10).rem==0)  { fputs("*",stdout); fflush (stdout);  }
    if(div(i,1000).rem==0){ fputs("\n",stdout); fflush (stdout); }
  }

  if(OutputCollocationsDictionary){
    fputs ("\nSaving data\n",stdout); fflush (stdout);
    vector<item> v;
    changeMapToVector(coll,v);
    if(v.size()>0){
      stable_sort (v.begin(), v.end(), compare_key);
      saveVectorToFile("collocations_abc.txt",v);
      stable_sort (v.begin(), v.end(), compare_val);
      saveVectorToFile("collocations_freq.txt",v);
    }
  }
  }
  else
    fputs ("\nNo files found in the directory ./corpus\n",stdout);  fflush (stdout);
  return 0;
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void findFiles(vector<string>& files, string dir){
  DIR *d, *d2;
  struct dirent *ent;
  string file, file2;
  if ((d = opendir(dir.c_str())) != NULL){
    while ((ent = readdir(d)) != NULL){
      file =  ent->d_name;
      if(file != "." && file != ".."){
        file2 = dir+"/"+file;
        if((d2 = opendir(file2.c_str())) != NULL) {
          closedir(d2);
          findFiles(files,file2);
        }
        else files.push_back(file2);
      }
    }
    closedir(d);
  }
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void saveVectorToFile(string file, vector<item> &v) {
  ofstream out(file.c_str());
  vector< item >::iterator it;
  for ( it=v.begin() ; it != v.end(); it++ )
    out << (*it).word << "\t" << (*it).freq << endl;
  out.close();
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
map<string,int>::iterator addToMap(map<string,int> &mymap, const string &line, const int f){
  map< string,int >::iterator it;
  it = mymap.find(line); 
  if(it != mymap.end())
  	(*it).second += f;
  else
  	it = (mymap.insert(pair<string,int>(line,f))).first ; 
  return it;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
long double dice(map<string,int> &dict1, map<string,int> &dict2, string& word1, string & word2){
  int x,y,xy;
  map<string,int>::iterator it;
  x = 1;   y = 1;   xy = 1;
  it = dict1.find(word1);
  if(it != dict1.end()) x = (*it).second;

  it = dict1.find(word2);
  if(it != dict1.end()) y = (*it).second;

  it = dict2.find(word1+"\t"+word2);
  if(it != dict2.end()) xy = (*it).second;

  return (long double)(2*xy)/(long double)(x+y);
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void splitSegment(vector<long double> &grs, vector<long double> &grs2, int st, int ln){
  long double min, avg;
  int i;
  if(grs2.size()>st+2){
    st++;
    min = grs2[st]  -  (grs2[st-1] + grs2[st+1])/2;
    i = st;
    while(st < ln){
      avg = grs2[st]  -  (grs2[st-1] + grs2[st+1])/2;
      if(avg < min ){
    	  min = avg;
    	  i = st;
   	  }
      st++;
    }
    grs[i] = exp(-20);
  }
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void makeCollSegmentation(vector<string>& list, map<string,int> &dict1, map<string,int> &dict2, map<string,int> &coll, FILE* output_file){
  unsigned int i,j;
  vector<long double> grs;
  vector<long double> grs2;
  long double gr,b4,b8,b20,avg;
  char buffer [200];
  string w;
  int coll_length;

  b4=exp(-4);
  b8=exp(-9);
  b20 = exp(-20);


  for(i=1;i<list.size();i++){
    gr = dice(dict1,dict2, list[i-1],list[i]);
    grs2.push_back(gr);
    grs.push_back(gr);
  }
  for(i=3;i<list.size();i++){
	  avg = (grs2[i-3]+grs2[i-1])/2;
    if(avg > grs2[i-2] && grs2[i-3]>b8 && grs2[i-1]>b8 )      grs[i-2] = b20;  // average minimum
  }
  for(i=1;i<list.size();i++){ // idedam taisykle taskui
    if( grs2[i-1]< b4 && (list[i]=="." || list[i-1]=="." || 
    	                    list[i]=="," || list[i-1]=="," || 
    	                    list[i]==":" || list[i-1]==":" || 
    	                    list[i]==";" || list[i-1]==";" || 
    	                    list[i]=="\"" || list[i-1]=="\"" || 
    	                    list[i]=="!" || list[i-1]=="!" || 
    	                    list[i]=="?" || list[i-1]=="?")){
      grs[i-1] = b20;
    }
  }
  for(i=0;i<list.size();i++){
  	if(i==0){
    	w = list[i];
  	  coll_length = 1;
    }
    else{
      if( grs[i-1] > b8){
        w = w + "_" + list[i];
        coll_length++;
      }
      else{
        if(coll_length > CollocationLengthLimit && LimitCollocationLength) {
     			splitSegment(grs,grs2,i-coll_length+1,coll_length-1);
     			i=i-coll_length+1;
        }
        else{
        	if(i-coll_length==0){
            fprintf(output_file, "%s",w.c_str()); // eilutes pradzoje nededame tarpo
            if(OutputCollocationsDictionary)  addToMap(coll,w);
          }
          else{
            fprintf(output_file, " %s",w.c_str());
            if(OutputCollocationsDictionary)  addToMap(coll,w);
          }
        }
        w = list[i];
        coll_length = 1;
      }
    }
    if(i==list.size()-1){
     // cia galas, atspausdiname ir baigiame, jei junginio ilgis < 8
      if(coll_length > CollocationLengthLimit  && LimitCollocationLength) {
     			splitSegment(grs,grs2,i-coll_length+1,coll_length-1);
     			i=i-coll_length+1;  // is naujo analizuoti reikia, kad atspausdinti
          w = list[i];
          coll_length=1;
      }
      else{
       	if(i+1==coll_length){
          fprintf(output_file, "%s",w.c_str()); // eilutes pradzoje nededame tarpo
          if(OutputCollocationsDictionary) addToMap(coll,w);
        }
        else{
          fprintf(output_file, " %s",w.c_str());
          if (OutputCollocationsDictionary) addToMap(coll,w);
        }
      }
    }
  }
  fprintf(output_file, "\n");
  grs.clear();
  grs2.clear();
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void makeStats(vector<string>& list,map<string,int> &dict1,map<string,int> &dict2){
  unsigned int i;
  string st;
  for(i=1;i<list.size();i++){
    addToMap(dict1,list[i-1]);
    st = list[i-1]+"\t"+list[i];
    addToMap(dict2,st);
  }
  if(list.size()>0) addToMap(dict1,list[list.size()-1]);
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void changeMapToVector(map<string, int> &m,vector<item> &v){
  map<string,int>::iterator it;
  it=m.begin();
  item p;
  while ( it != m.end()){
  	p.word = (*it).first;
  	p.freq = (*it).second;
  	v.push_back(p);
		it++;
  }
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void process_file_coll(string file, string file_out, map<string,int>& dict1, map<string,int> &dict2, map<string,int> &coll){
  char* cline = new char[200000];
  vector<string> list;
  string line, word;
  int pos,pos1;
  FILE* out,*in;
  in = fopen(file.c_str(),"rb");
  out = fopen(file_out.c_str(),"wb");
  if ( in && out ){
    while(!feof(in)){
    	if(fgets(cline,199999,in)){
        if(cline[strlen(cline)-1]=='\n') cline[strlen(cline)-1]='\0';
        if(cline[strlen(cline)-1]=='\r') cline[strlen(cline)-1]='\0';
        list.clear();
        line = cline;
        pos1 = -1;
        pos = line.find(" ",pos1+1);
        while(pos > -1){
          word = line.substr(pos1+1,pos-pos1-1);
          if(word.size()>0){
            list.push_back(word);
          }
          pos1 = pos;
          pos = line.find(" ",pos1+1);
        }
        if(line.size()>pos1){
          line = line.substr(pos1+1,pos-pos1-1);
          if(line.size()>0){
            list.push_back(line);
          }
        }
        makeCollSegmentation(list,dict1, dict2,coll,out);
      }
    }
    fclose(in);
    fclose(out);
  }
  else cout << "nepavyko atidaryti " << file << "\n" << file_out << endl;
  
  delete [] cline;
}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void process_file_freq(string file,map<string,int> &dict1,map<string,int> &dict2){
  char* cline = new char[200000];
  vector<string> list,list2;
  string line, line2, word, word2;
  int pos,pos1,counter;
  FILE *in;
  in = fopen(file.c_str(),"rb");
  
  if ( in ){
    while(!feof(in)){
      if(fgets(cline,199999,in)){
        if(cline[strlen(cline)-1]=='\n') cline[strlen(cline)-1]='\0';
        if(cline[strlen(cline)-1]=='\r') cline[strlen(cline)-1]='\0';
        list.clear();
        list2.clear();
        line = cline;
        
        pos1 = -1;
        pos = line.find(" ",pos1+1);
        while(pos > -1){
          word = line.substr(pos1+1,pos-pos1-1);
          if(word.size()>0){
            list.push_back(word);
          }
          pos1 = pos;
          pos = line.find(" ",pos1+1);
        }
        if(line.size()>pos1){
          line = line.substr(pos1+1,pos-pos1-1);
          if(line.size()>0){
            list.push_back(line);
          }
        }
        makeStats(list,dict1, dict2);
      }
    }
    fclose(in);
  }
  else cout << "nepavyko atidaryti " << file << endl;
  delete [] cline;
}

