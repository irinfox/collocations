#!/usr/bin/perl -w

# written by Vidas Daudaravicius
# e-mail: vidas@donelaitis.vdu.lt

use File::Find;


my $directory = "corpus";

while (@ARGV) {
	$_ = shift;
	/^-d$/ && ($directory = shift, next);
}


@files = ();
find( \&findFiles, ($directory) );
while(<@files>){
  $file = $_;
  print $_;
  print "\n";
  open( IN, "+<:raw", $_);
  if(!eof(IN)){
    open( OUT, ">:raw", $_."t");
#  binmode(IN, ":utf8");
#  binmode(OUT, ":utf8");
    while (readline(IN)) {
      printf OUT "%s", lc($_);
    }
    close(IN);  
    close(OUT);  
    unlink($file);
    rename($file."t",$file);
  }
}

sub findFiles {
  push @files, $File::Find::name;
}

